import pandas as pd
import numpy as np
import glob
import os

# read csv, clean and optimize the dataframe and combine the dataframes into one
def read_clean_combine_csv(directory, df, exclude=None):
    excludepath = os.path.join(directory,exclude)
    print(excludepath)
    print()
    for csv_file in glob.glob(os.path.join(directory,'*')):
        if(excludepath != csv_file):
            df1 = pd.read_csv(csv_file)
            df1 = df1[df1['Protocol'] != 'Protocol']
            df1 = optimize_and_clean_df(df1)
            df = pd.concat([df,df1], ignore_index=True)
    return df
    

def optimize_and_clean_df(df):
    # convert columns to correct data types
    df[df.columns.difference(['Dst Port','Protocol','Timestamp','Label'])] = df[df.columns.difference(['Dst Port','Protocol','Timestamp','Label'])].apply(pd.to_numeric, errors='coerce')
    df['Timestamp'] = pd.to_datetime(df.Timestamp, format="%d/%m/%Y %H:%M:%S")
    
    # reduce memory allocation of dataframe with function 
    df, NAlist = reduce_mem_usage(df)
    
    # categorize categorical columns for additional optimization
    df[['Dst Port','Protocol','Label']] = df[['Dst Port','Protocol','Label']].astype('category')
    
    # return dataframe
    return df
    
# taken from https://www.kaggle.com/arjanso/reducing-dataframe-memory-size-by-65
def reduce_mem_usage(props):
    start_mem_usg = props.memory_usage().sum() / 1024**2 
    print("Memory usage of properties dataframe is :",start_mem_usg," MB")
    NAlist = [] # Keeps track of columns that have missing values filled in. 
    for col in props.columns:
        if props[col].dtype != object and props[col].dtype != 'datetime64[ns]':  # Exclude strings and datetime
            
            # make variables for Int, max and min
            IsInt = False
            mx = props[col].max()
            mn = props[col].min()
            
            # Integer does not support NA, therefore, NA needs to be filled
            if not np.isfinite(props[col]).all(): 
                NAlist.append(col)
                props[col].fillna(mn-1,inplace=True)  
                   
            # test if column can be converted to an integer
            asint = props[col].fillna(0).astype(np.int64)
            result = (props[col] - asint)
            result = result.sum()
            if result > -0.01 and result < 0.01:
                IsInt = True

            
            # Make Integer/unsigned Integer datatypes
            if IsInt:
                if mn >= 0:
                    if mx < 255:
                        props[col] = props[col].astype(np.uint8)
                    elif mx < 65535:
                        props[col] = props[col].astype(np.uint16)
                    elif mx < 4294967295:
                        props[col] = props[col].astype(np.uint32)
                    else:
                        props[col] = props[col].astype(np.uint64)
                else:
                    if mn > np.iinfo(np.int8).min and mx < np.iinfo(np.int8).max:
                        props[col] = props[col].astype(np.int8)
                    elif mn > np.iinfo(np.int16).min and mx < np.iinfo(np.int16).max:
                        props[col] = props[col].astype(np.int16)
                    elif mn > np.iinfo(np.int32).min and mx < np.iinfo(np.int32).max:
                        props[col] = props[col].astype(np.int32)
                    elif mn > np.iinfo(np.int64).min and mx < np.iinfo(np.int64).max:
                        props[col] = props[col].astype(np.int64)    
            
            # Make float datatypes 32 bit
            else:
                props[col] = props[col].astype(np.float32)
          
    
    # Print final result
    print("___MEMORY USAGE AFTER COMPLETION:___")
    mem_usg = props.memory_usage().sum() / 1024**2 
    print("Memory usage is: ",mem_usg," MB")
    print("This is ",100*mem_usg/start_mem_usg,"% of the initial size")
    return props, NAlist